// Automatic FlutterFlow imports
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future newCustomAction() async {
  // sum of the points in the user table and points earned from completing the quest
// Assuming the user table is stored in a database and the points earned from completing the quest are stored in a separate variable

  // Retrieve the user table from the database
  List<User> users = await database.retrieveUsers();

  // Calculate the total points earned by summing up the points in the user table and the points earned from completing the quest
  int totalPoints = 0;
  for (User user in users) {
    totalPoints += user.points;
  }
  totalPoints += pointsEarnedFromQuest;

  // Return the total points earned
  return totalPoints;
}
