import '../database.dart';

class QuestsTable extends SupabaseTable<QuestsRow> {
  @override
  String get tableName => 'quests';

  @override
  QuestsRow createRow(Map<String, dynamic> data) => QuestsRow(data);
}

class QuestsRow extends SupabaseDataRow {
  QuestsRow(super.data);

  @override
  SupabaseTable get table => QuestsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  String? get tier => getField<String>('tier');
  set tier(String? value) => setField<String>('tier', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  List<String> get exercise => getListField<String>('exercise');
  set exercise(List<String>? value) => setListField<String>('exercise', value);

  int? get pointsReward => getField<int>('points_reward');
  set pointsReward(int? value) => setField<int>('points_reward', value);

  int? get calories => getField<int>('calories');
  set calories(int? value) => setField<int>('calories', value);
}
