// Export pages
export '/pages/dash_board/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/on_boarding/slide_show/slide_show_widget.dart'
    show SlideShowWidget;
export '/pages/on_boarding/auth2/auth2_widget.dart' show Auth2Widget;
export '/pages/on_boarding/personal_details/personal_details_widget.dart'
    show PersonalDetailsWidget;
export '/pages/profile/status/status_widget.dart' show StatusWidget;
export '/pages/profile/setting/setting_widget.dart' show SettingWidget;
export '/pages/community/feeds/feeds_widget.dart' show FeedsWidget;
export '/pages/community/post/post_widget.dart' show PostWidget;
export '/pages/community/leaderboard/leaderboard_widget.dart'
    show LeaderboardWidget;
export '/pages/quests/main_quests/main_quests_widget.dart'
    show MainQuestsWidget;
export '/pages/quests/nightmare/nightmare_widget.dart' show NightmareWidget;
export '/pages/quests/hardcore/hardcore_widget.dart' show HardcoreWidget;
export '/pages/quests/mediocre/mediocre_widget.dart' show MediocreWidget;
export '/pages/quests/beginner/beginner_widget.dart' show BeginnerWidget;
export '/pages/quests/test/test_widget.dart' show TestWidget;
export '/pages/profile/update_information/update_information_widget.dart'
    show UpdateInformationWidget;
export '/pages/profile/customer_support/customer_support_widget.dart'
    show CustomerSupportWidget;
export '/pages/admin/pdf/pdf_widget.dart' show PdfWidget;
export '/pages/admin/admins_staff/admins_staff_widget.dart'
    show AdminsStaffWidget;
export '/pages/admin/staff/staff_widget.dart' show StaffWidget;
export '/pages/admin/viewer/viewer_widget.dart' show ViewerWidget;
