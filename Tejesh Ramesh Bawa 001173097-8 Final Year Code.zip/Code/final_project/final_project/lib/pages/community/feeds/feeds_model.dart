import '/flutter_flow/flutter_flow_util.dart';
import 'feeds_widget.dart' show FeedsWidget;
import 'package:flutter/material.dart';

class FeedsModel extends FlutterFlowModel<FeedsWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
