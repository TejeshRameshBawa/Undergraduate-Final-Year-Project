import '/flutter_flow/flutter_flow_util.dart';
import 'main_quests_widget.dart' show MainQuestsWidget;
import 'package:flutter/material.dart';

class MainQuestsModel extends FlutterFlowModel<MainQuestsWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
