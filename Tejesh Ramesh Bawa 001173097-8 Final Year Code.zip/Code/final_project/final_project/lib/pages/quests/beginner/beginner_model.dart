import '/flutter_flow/flutter_flow_util.dart';
import 'beginner_widget.dart' show BeginnerWidget;
import 'package:flutter/material.dart';

class BeginnerModel extends FlutterFlowModel<BeginnerWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
