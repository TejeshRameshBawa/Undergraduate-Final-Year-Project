import '/flutter_flow/flutter_flow_util.dart';
import 'mediocre_widget.dart' show MediocreWidget;
import 'package:flutter/material.dart';

class MediocreModel extends FlutterFlowModel<MediocreWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
