import '/flutter_flow/flutter_flow_util.dart';
import 'nightmare_widget.dart' show NightmareWidget;
import 'package:flutter/material.dart';

class NightmareModel extends FlutterFlowModel<NightmareWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
