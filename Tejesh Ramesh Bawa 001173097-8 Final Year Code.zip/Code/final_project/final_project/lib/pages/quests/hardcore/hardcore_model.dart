import '/flutter_flow/flutter_flow_util.dart';
import 'hardcore_widget.dart' show HardcoreWidget;
import 'package:flutter/material.dart';

class HardcoreModel extends FlutterFlowModel<HardcoreWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
