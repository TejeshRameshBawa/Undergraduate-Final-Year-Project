import '/flutter_flow/flutter_flow_util.dart';
import 'customer_support_widget.dart' show CustomerSupportWidget;
import 'package:flutter/material.dart';

class CustomerSupportModel extends FlutterFlowModel<CustomerSupportWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
