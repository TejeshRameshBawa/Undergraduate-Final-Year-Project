import '/flutter_flow/flutter_flow_util.dart';
import 'update_information_widget.dart' show UpdateInformationWidget;
import 'package:flutter/material.dart';

class UpdateInformationModel extends FlutterFlowModel<UpdateInformationWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for UpdateHeight widget.
  FocusNode? updateHeightFocusNode;
  TextEditingController? updateHeightTextController;
  String? Function(BuildContext, String?)? updateHeightTextControllerValidator;
  // State field(s) for UpdateWeight widget.
  FocusNode? updateWeightFocusNode;
  TextEditingController? updateWeightTextController;
  String? Function(BuildContext, String?)? updateWeightTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    updateHeightFocusNode?.dispose();
    updateHeightTextController?.dispose();

    updateWeightFocusNode?.dispose();
    updateWeightTextController?.dispose();
  }
}
