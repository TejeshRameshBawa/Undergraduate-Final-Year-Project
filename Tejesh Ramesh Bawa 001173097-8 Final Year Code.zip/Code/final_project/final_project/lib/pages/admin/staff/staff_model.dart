import '/flutter_flow/flutter_flow_util.dart';
import 'staff_widget.dart' show StaffWidget;
import 'package:flutter/material.dart';

class StaffModel extends FlutterFlowModel<StaffWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
