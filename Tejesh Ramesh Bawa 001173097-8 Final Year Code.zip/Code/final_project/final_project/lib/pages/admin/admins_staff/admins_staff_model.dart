import '/flutter_flow/flutter_flow_util.dart';
import 'admins_staff_widget.dart' show AdminsStaffWidget;
import 'package:flutter/material.dart';

class AdminsStaffModel extends FlutterFlowModel<AdminsStaffWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
