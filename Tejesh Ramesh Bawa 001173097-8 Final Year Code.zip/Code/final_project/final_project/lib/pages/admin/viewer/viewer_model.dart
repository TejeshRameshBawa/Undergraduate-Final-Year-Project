import '/flutter_flow/flutter_flow_util.dart';
import 'viewer_widget.dart' show ViewerWidget;
import 'package:flutter/material.dart';

class ViewerModel extends FlutterFlowModel<ViewerWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
