import '/flutter_flow/flutter_flow_util.dart';
import 'personal_details_widget.dart' show PersonalDetailsWidget;
import 'package:flutter/material.dart';

class PersonalDetailsModel extends FlutterFlowModel<PersonalDetailsWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for AgeTextField widget.
  FocusNode? ageTextFieldFocusNode;
  TextEditingController? ageTextFieldTextController;
  String? Function(BuildContext, String?)? ageTextFieldTextControllerValidator;
  // State field(s) for GenderTextField widget.
  FocusNode? genderTextFieldFocusNode;
  TextEditingController? genderTextFieldTextController;
  String? Function(BuildContext, String?)?
      genderTextFieldTextControllerValidator;
  // State field(s) for HeightTextField widget.
  FocusNode? heightTextFieldFocusNode;
  TextEditingController? heightTextFieldTextController;
  String? Function(BuildContext, String?)?
      heightTextFieldTextControllerValidator;
  // State field(s) for WeightTextField widget.
  FocusNode? weightTextFieldFocusNode;
  TextEditingController? weightTextFieldTextController;
  String? Function(BuildContext, String?)?
      weightTextFieldTextControllerValidator;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    ageTextFieldFocusNode?.dispose();
    ageTextFieldTextController?.dispose();

    genderTextFieldFocusNode?.dispose();
    genderTextFieldTextController?.dispose();

    heightTextFieldFocusNode?.dispose();
    heightTextFieldTextController?.dispose();

    weightTextFieldFocusNode?.dispose();
    weightTextFieldTextController?.dispose();
  }
}
