package com.mycompany.webs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
