import '../database.dart';

class BadgesTable extends SupabaseTable<BadgesRow> {
  @override
  String get tableName => 'badges';

  @override
  BadgesRow createRow(Map<String, dynamic> data) => BadgesRow(data);
}

class BadgesRow extends SupabaseDataRow {
  BadgesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => BadgesTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  String? get names => getField<String>('names');
  set names(String? value) => setField<String>('names', value);

  String? get picture => getField<String>('picture');
  set picture(String? value) => setField<String>('picture', value);

  int? get requiredPoints => getField<int>('required_points');
  set requiredPoints(int? value) => setField<int>('required_points', value);
}
