import '../database.dart';

class PdfTable extends SupabaseTable<PdfRow> {
  @override
  String get tableName => 'pdf';

  @override
  PdfRow createRow(Map<String, dynamic> data) => PdfRow(data);
}

class PdfRow extends SupabaseDataRow {
  PdfRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => PdfTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String get pdf => getField<String>('pdf')!;
  set pdf(String value) => setField<String>('pdf', value);

  String get name => getField<String>('name')!;
  set name(String value) => setField<String>('name', value);
}
