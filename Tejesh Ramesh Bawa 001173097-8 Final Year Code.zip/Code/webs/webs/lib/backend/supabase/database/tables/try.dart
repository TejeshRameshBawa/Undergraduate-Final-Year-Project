import '../database.dart';

class TryTable extends SupabaseTable<TryRow> {
  @override
  String get tableName => 'try';

  @override
  TryRow createRow(Map<String, dynamic> data) => TryRow(data);
}

class TryRow extends SupabaseDataRow {
  TryRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TryTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  List<String> get tryField => getListField<String>('try');
  set tryField(List<String>? value) => setListField<String>('try', value);
}
