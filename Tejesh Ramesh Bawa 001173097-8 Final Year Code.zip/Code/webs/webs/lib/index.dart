// Export pages
export '/pages/personal_details/personal_details_widget.dart'
    show PersonalDetailsWidget;
export '/pages/auth2/auth2_widget.dart' show Auth2Widget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/edit/edit_widget.dart' show EditWidget;
export '/pages/upload_quest/upload_quest_widget.dart' show UploadQuestWidget;
export '/pages/pdf/pdf_widget.dart' show PdfWidget;
