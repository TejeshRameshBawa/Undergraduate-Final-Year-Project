import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/pages/test/test_widget.dart';
import 'again_widget.dart' show AgainWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AgainModel extends FlutterFlowModel<AgainWidget> {
  ///  Local state fields for this component.

  List<String> callTypes = [];
  void addToCallTypes(String item) => callTypes.add(item);
  void removeFromCallTypes(String item) => callTypes.remove(item);
  void removeAtIndexFromCallTypes(int index) => callTypes.removeAt(index);
  void insertAtIndexInCallTypes(int index, String item) =>
      callTypes.insert(index, item);
  void updateCallTypesAtIndex(int index, Function(String) updateFn) =>
      callTypes[index] = updateFn(callTypes[index]);

  ///  State fields for stateful widgets in this component.

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // State field(s) for QuestName widget.
  FocusNode? questNameFocusNode;
  TextEditingController? questNameTextController;
  String? Function(BuildContext, String?)? questNameTextControllerValidator;
  // Models for test dynamic component.
  late FlutterFlowDynamicModels<TestModel> testModels;
  // State field(s) for Points widget.
  FocusNode? pointsFocusNode;
  TextEditingController? pointsTextController;
  String? Function(BuildContext, String?)? pointsTextControllerValidator;
  // State field(s) for calories widget.
  FocusNode? caloriesFocusNode;
  TextEditingController? caloriesTextController;
  String? Function(BuildContext, String?)? caloriesTextControllerValidator;

  @override
  void initState(BuildContext context) {
    testModels = FlutterFlowDynamicModels(() => TestModel());
  }

  @override
  void dispose() {
    questNameFocusNode?.dispose();
    questNameTextController?.dispose();

    testModels.dispose();
    pointsFocusNode?.dispose();
    pointsTextController?.dispose();

    caloriesFocusNode?.dispose();
    caloriesTextController?.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
