import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pages/again/again_widget.dart';
import 'upload_quest_widget.dart' show UploadQuestWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class UploadQuestModel extends FlutterFlowModel<UploadQuestWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for again component.
  late AgainModel againModel;

  @override
  void initState(BuildContext context) {
    againModel = createModel(context, () => AgainModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    againModel.dispose();
  }
}
